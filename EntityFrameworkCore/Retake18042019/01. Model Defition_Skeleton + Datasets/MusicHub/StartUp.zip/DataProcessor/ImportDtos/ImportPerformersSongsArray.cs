﻿namespace MusicHub.DataProcessor.ImportDtos
{
    public class ImportPerformersSongsArray
    {
        public int Id { get; set; }
    }
}